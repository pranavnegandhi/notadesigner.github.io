﻿namespace Notadesigner
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rbBCD = new System.Windows.Forms.RadioButton();
            this.rbBinary = new System.Windows.Forms.RadioButton();
            this.clock = new Notadesigner.BinaryClock();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.clock)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rbBCD);
            this.groupBox1.Controls.Add(this.rbBinary);
            this.groupBox1.Location = new System.Drawing.Point(12, 195);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(360, 71);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Mode";
            // 
            // rbBCD
            // 
            this.rbBCD.AutoSize = true;
            this.rbBCD.Location = new System.Drawing.Point(10, 45);
            this.rbBCD.Name = "rbBCD";
            this.rbBCD.Size = new System.Drawing.Size(128, 17);
            this.rbBCD.TabIndex = 6;
            this.rbBCD.Text = "Binary-coded Decimal";
            this.rbBCD.UseVisualStyleBackColor = true;
            this.rbBCD.CheckedChanged += new System.EventHandler(this.rbBCD_CheckedChanged);
            // 
            // rbBinary
            // 
            this.rbBinary.AutoSize = true;
            this.rbBinary.Checked = true;
            this.rbBinary.Location = new System.Drawing.Point(10, 22);
            this.rbBinary.Name = "rbBinary";
            this.rbBinary.Size = new System.Drawing.Size(54, 17);
            this.rbBinary.TabIndex = 5;
            this.rbBinary.TabStop = true;
            this.rbBinary.Text = "Binary";
            this.rbBinary.UseVisualStyleBackColor = true;
            this.rbBinary.CheckedChanged += new System.EventHandler(this.rbBinary_CheckedChanged);
            // 
            // clock
            // 
            this.clock.Location = new System.Drawing.Point(12, 12);
            this.clock.Mode = Notadesigner.BinaryClock.Modes.Binary;
            this.clock.Name = "clock";
            this.clock.Size = new System.Drawing.Size(360, 170);
            this.clock.TabIndex = 0;
            this.clock.TabStop = false;
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(384, 277);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.clock);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Main";
            this.Text = "Binary Clock";
            this.Load += new System.EventHandler(this.Main_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.clock)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private BinaryClock clock;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rbBCD;
        private System.Windows.Forms.RadioButton rbBinary;
    }
}

