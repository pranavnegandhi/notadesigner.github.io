This archive contains a FlashDevelop AS3 project.
To compile, launch the project in your FlashDevelop 
IDE and run the project. If all goes well, the files 
should compile and launch the demo in the Flash 
Player.

To change the effect being displayed, open Main.as 
in the IDE for editing and change it from SineWave 
to WaveEffect. More effects can be created using 
the same scaffolding by extending the BaseEffect 
class and implementing the IEffect interface.

Underwater in Egypt is used under the Creative Commons 
license from http://www.flickr.com/photos/ehole/4389361985/in/set-72157623388632379/.

Creative Commons license terms can be read online 
at http://creativecommons.org/licenses/by/2.0/