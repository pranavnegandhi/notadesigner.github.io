﻿using System.Windows;
using System.Windows.Controls;
using Notadesigner.ConwaysLife.Game;

namespace Notadesigner.ConwaysLife
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private BoardModel model = new BoardModel();

        public MainWindow()
        {
            InitializeComponent();
            this.model.Update += new BoardModel.OnUpdate(model_Update);
        }

		void view_Click(object sender, ClickEventArgs e)
		{
			this.model.ToggleCell(e.X, e.Y);
		}

        void model_Update(object sender)
        {
            this.view.Update(this.model.Cells);
        }

        private void toggleStart_Click(object sender, RoutedEventArgs e)
        {
            if (this.model.IsActive)
            {
                this.btnNext.IsEnabled = true;
                ((Button)sender).Content = "Start";
                this.model.Stop();
            }
            else
            {
                this.btnNext.IsEnabled = false;
                ((Button)sender).Content = "Stop";
                this.model.Start();
            }
        }

        private void nextIteration_Click(object sender, RoutedEventArgs e)
        {
            if (this.model.IsActive)
            {
                return;
            }

            this.model.Next();
        }

        private void clear_Click(object sender, RoutedEventArgs e)
        {
            this.btnNext.IsEnabled = true;
            this.btnStart.Content = "Start";

            this.model.Clear();
        }

        private void randomize_Click(object sender, RoutedEventArgs e)
        {
            this.btnNext.IsEnabled = true;
            this.btnStart.Content = "Start";

            this.model.Randomize();
        }
    }
}
