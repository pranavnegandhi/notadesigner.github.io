﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace Notadesigner
{
    class BinaryClock : PictureBox
    {
        private const int ROW_COUNT = 6;

        private const int RECT_SIZE = 20;

        private const int RECT_OFFSET = 10;

        private const int COL_OFFSET = BinaryClock.ROW_COUNT * (BinaryClock.RECT_SIZE + BinaryClock.RECT_OFFSET);

        private delegate void Draw(int value, Graphics g, ref Rectangle area);

        public enum Modes { BCD, Binary };

        private Timer _pulse;

        private Modes _mode;

        private int _columns;

        private Draw _draw;

        private Brush _onBrush;

        private Brush _offBrush;

        public BinaryClock()
        {
            this._offBrush = new SolidBrush(Color.Black);
            this._onBrush = new SolidBrush(Color.Red);
            this.Mode = Modes.Binary;

            this._pulse = new Timer();
            this._pulse.Interval = 1000;
            this._pulse.Tick += new EventHandler(this._pulseTick);
            
            this.Paint += new PaintEventHandler(this._paint);
        }

        public void Start()
        {
            this._pulse.Start();
        }

        public void Stop()
        {
            this._pulse.Stop();
        }

        public Modes Mode
        {
            get
            {
                return this._mode;
            }

            set
            {
                this._mode = value;
                if (Modes.Binary == this._mode)
                {
                    this._columns = 1;
                    this._draw = this._drawBinary;
                }
                else
                {
                    this._columns = 2;
                    this._draw = this._drawBCD;
                }

                this.Invalidate();
            }
        }

        void _pulseTick(object sender, EventArgs e)
        {
            this.Invalidate();
        }

        void _paint(object sender, PaintEventArgs e)
        {
            DateTime dt;
            int h;
            int m;
            int s;
            Rectangle area;
            int offsetX;
            int offsetY;

            dt = DateTime.Now;
            h = dt.Hour;
            m = dt.Minute;
            s = dt.Second;

            area = new Rectangle(0, this.Height - BinaryClock.RECT_SIZE, BinaryClock.RECT_SIZE, BinaryClock.RECT_SIZE);
            offsetX = this._columns * (BinaryClock.RECT_SIZE + BinaryClock.RECT_OFFSET);
            offsetY = BinaryClock.COL_OFFSET;

            // Get bits for the hours component
            this._draw(h, e.Graphics, ref area);
            area.Offset(offsetX, offsetY);

            // Get bits for the minutes component
            this._draw(m, e.Graphics, ref area);
            area.Offset(offsetX, offsetY);

            // Get bits for the seconds component
            this._draw(s, e.Graphics, ref area);
        }

        void _drawBinary(int value, Graphics g, ref Rectangle area)
        {
            int bit;
            int i;

            for (i = 0; i < 6; i++)
            {
                bit = value & (1 << i);

                if (0 == bit)
                    g.FillRectangle(_offBrush, area);
                else
                    g.FillRectangle(_onBrush, area);
                    
                
                area.Offset(0, - (BinaryClock.RECT_SIZE + BinaryClock.RECT_OFFSET));
            }
        }

        void _drawBCD(int value, Graphics g, ref Rectangle area)
        {
            int digit1;
            int digit2;
            Rectangle area2;
            
            digit1 = value / 10;
            digit2 = value % 10;
            area2 = new Rectangle(area.X, area.Y, BinaryClock.RECT_SIZE, BinaryClock.RECT_SIZE);

            this._drawBinary(digit1, g, ref area2);
            area2.Offset(BinaryClock.RECT_SIZE + BinaryClock.RECT_OFFSET, BinaryClock.COL_OFFSET);
            this._drawBinary(digit2, g, ref area2);

            area.Offset(0, -BinaryClock.COL_OFFSET);
        }
    }
}
