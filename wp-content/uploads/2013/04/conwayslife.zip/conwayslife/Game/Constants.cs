﻿using System;

namespace Notadesigner.ConwaysLife.Game
{
    public class Constants
    {
        public const double CELL_SIZE = 10;

        public const int CELLS_X = 80;

        public const int CELLS_Y = 80;
    }
}
