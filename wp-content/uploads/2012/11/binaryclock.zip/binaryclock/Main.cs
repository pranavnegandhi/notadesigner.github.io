﻿using System;
using System.Windows.Forms;

namespace Notadesigner
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
        }

        private void Main_Load(object sender, EventArgs e)
        {
            this.clock.Start();
        }

        private void rbBinary_CheckedChanged(object sender, EventArgs e)
        {
            if (this.rbBinary.Checked)
                this.clock.Mode = BinaryClock.Modes.Binary;
        }

        private void rbBCD_CheckedChanged(object sender, EventArgs e)
        {
            if (this.rbBCD.Checked)
                this.clock.Mode = BinaryClock.Modes.BCD;
        }
    }
}
