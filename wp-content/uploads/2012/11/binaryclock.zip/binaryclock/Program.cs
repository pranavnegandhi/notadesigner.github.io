﻿using System;
using System.Windows.Forms;

namespace Notadesigner
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Main frm;
            
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            frm = new Main();
            Application.Run(frm);
        }
    }
}
